from flask import Flask, Response, request
import pymongo
import json
from bson.objectid import ObjectId


app = Flask(__name__)


try :
     mongo = pymongo.MongoClient(
          host="localhost", 
          port=27017,
          serverSelectionTimeoutMS = 1000 
     )
     db = mongo.com
     mongo.server_info()

except:
     print("ERROR - Cannot connect")
#------------------------------------------------------
@app.route("/users", methods = ["GET"] ) # 
def get_user():

     try :
          data = list(db.user.find())
          for user in data :
               user["_id"] = str(user["_id"])

          return data
     except Exception as ex:
          print (ex)
          user = {
               "name" : request.form["name"],
               "Lname" : request.form["Lname"]
               }
          dbResponse = db.users.insert_one(user)
          return Response(
               response = json.dumps(
                    data
               ),
               status= 500,
               mimetype= "application/json"
          )
#------------------------------------------------------

@app.route("/" ) # , methods = ["POST"]
def create_user():

     try :
          user = {
               "name" : request.form["name"],
               "Lname" : request.form["Lname"]
               }
          dbResponse = db.users.insert_one(user)
          return Response(
               response = json.dumps(
                    {"massage" : "user create", "id" :f"{dbResponse.insert_id}"}
               ),
               status= 200,
               mimetype= "application/json"
          )
     except Exception as ex :
          print (ex)
#-------------------------------------------------------------------

@app.route("/users/<id>", method = ["PATCH"])
def update(id):
     try:
          dbResponse = db.user.update_one(
               { "_id" : ObjectId(id)},
               {"$set" : {"name" : request.form["name"]}}
          )
          for attr in dir(dbResponse) :
               print ("********{attr}************")
     except :
          print ("***************************")


if __name__ == '__main__':
     app.run(debug=True)
     