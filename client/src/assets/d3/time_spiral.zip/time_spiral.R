library(dplyr)
library(readxl)
library(ggplot2)
library(readr)
df <- read_csv("C:/Mew/Project/tmp_2012-2016/test_meantmp_2012_2014.csv")
View(df)

df$time = with(df, as.POSIXct(paste(date, day), tz="GMT"))

df$m <- as.numeric(df$time)
df$year <- as.Date(df$time)
sample <- data.frame(date = df$date,
                     date1 = seq.Date(from = as.Date("2012-01-01"), to = as.Date("2014-12-31"), by = 1),
                     day_num = 0:1095,
                     
                     rain = df$`300201`)


ggplot(sample, aes(day_num %% 365, 
                   date1, height = rain, fill = rain)) + 
  geom_tile() + 
  scale_y_continuous(limits = c(-20, NA),) +
  scale_x_continuous(limits = c(1, 365),breaks = 30*0:11, minor_breaks = NULL, labels = month.abb) +
  #coord_polar() + 
  scale_fill_viridis_c() + theme_minimal()+
  labs(x="Day",y="year",fill="rain")+
  ggtitle("station 300201 (2012-2018)")

#------------------------------------------------
ggplot(sample, aes(x=day_num %% 365, xend = day_num %% 365, 
                   y=spiralTime,yend = spiralTime
                   , fill = temp)) + 
  geom_tile() + 
  scale_y_date(limits = range(sample$spiralTime),
                   breaks=seq(min(sample$spiralTime),max(sample$spiralTime)),"years") +
  scale_x_continuous(limits = c(1, 365),breaks = 30*0:11, minor_breaks = NULL, labels = month.abb) +
  #coord_polar() + 
  scale_fill_viridis_c() + theme_minimal()+
  labs(x="Day",y="year",fill="temp")+
  ggtitle("station 300201 (2012-2016)")
